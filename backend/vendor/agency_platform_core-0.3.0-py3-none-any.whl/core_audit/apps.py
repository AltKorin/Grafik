from django.apps import AppConfig


class CoreAuditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_audit'
    verbose_name = 'Audyt'

    def ready(self):
        import core_audit.signals  # noqa: F401
