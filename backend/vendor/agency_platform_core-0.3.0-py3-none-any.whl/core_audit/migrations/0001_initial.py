import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='LoginEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('event_type', models.CharField(choices=[('login', 'Logowanie'), ('logout', 'Wylogowanie'), ('failed', 'Nieudana próba')], max_length=10, verbose_name='typ zdarzenia')),
                ('username_attempted', models.CharField(blank=True, max_length=150, verbose_name='próba loginu')),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True, verbose_name='adres IP')),
                ('user_agent', models.CharField(blank=True, max_length=500, verbose_name='user agent')),
                ('timestamp', models.DateTimeField(auto_now_add=True, verbose_name='czas')),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='login_events', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'zdarzenie logowania',
                'verbose_name_plural': 'zdarzenia logowania',
                'ordering': ['-timestamp'],
            },
        ),
    ]
