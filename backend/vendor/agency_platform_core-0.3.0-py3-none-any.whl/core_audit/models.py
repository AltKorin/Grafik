from django.conf import settings
from django.db import models


class LoginEvent(models.Model):
    """Niemutowalny log logowań — audyt bezpieczeństwa wymagany dla każdego
    projektu klienckiego (patrz CLAUDE.md)."""

    LOGIN = 'login'
    LOGOUT = 'logout'
    FAILED = 'failed'
    EVENT_CHOICES = [
        (LOGIN, 'Logowanie'),
        (LOGOUT, 'Wylogowanie'),
        (FAILED, 'Nieudana próba'),
    ]

    event_type = models.CharField('typ zdarzenia', max_length=10, choices=EVENT_CHOICES)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='login_events',
    )
    username_attempted = models.CharField('próba loginu', max_length=150, blank=True)
    ip_address = models.GenericIPAddressField('adres IP', null=True, blank=True)
    user_agent = models.CharField('user agent', max_length=500, blank=True)
    timestamp = models.DateTimeField('czas', auto_now_add=True)

    class Meta:
        verbose_name = 'zdarzenie logowania'
        verbose_name_plural = 'zdarzenia logowania'
        ordering = ['-timestamp']

    def __str__(self):
        return f'{self.event_type} — {self.username_attempted or self.user} — {self.timestamp:%Y-%m-%d %H:%M}'

    def save(self, *args, **kwargs):
        if self.pk:
            raise PermissionError('LoginEvent jest niemutowalny — nie można edytować.')
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise PermissionError('LoginEvent nie może być usunięty.')
