from django.conf import settings
from django.core.exceptions import ImproperlyConfigured, ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone
from simple_history.models import HistoricalRecords

# Model obiektu-właściciela (sala/hotel/restauracja/...) jest specyficzny per
# klient — nie każdy klient agencji ma ten koncept, i ci którzy go mają nie
# nazywają go tak samo. Rozwiązywane leniwie przez string 'app_label.Model'
# przekazany bezpośrednio do ForeignKey — dokładnie ten sam wzorzec, jakim
# Django samo rozwiązuje `settings.AUTH_USER_MODEL` (żadnego
# `apps.get_model()` nie trzeba wywoływać ręcznie, ForeignKey robi to leniwie
# przy starcie rejestru aplikacji). Klient BEZ tego ustawienia dostaje czytelny
# ImproperlyConfigured zamiast tajemniczego błędu przy starcie.
#
# Odrzucona alternatywa: zdjąć FK i zostawić `CharField` z wolnym tekstem —
# prostsze, zero konfiguracji, ale traci referencyjną integralność (nie da się
# np. `on_delete=SET_NULL` gdy obiekt zniknie) i kłóci się z resztą konwencji
# tego repo, które stawia mocno na integralność audytu (patrz CLAUDE.md).
try:
    _WLASCICIEL_MODEL = settings.MAGAZYN_WLASCICIEL_MODEL
except AttributeError:
    raise ImproperlyConfigured(
        "core_magazyn wymaga ustawienia MAGAZYN_WLASCICIEL_MODEL = 'app_label.ModelName' "
        "w settings.py klienta — wskazuje model obiektu-właściciela (np. sali/hotelu/"
        "restauracji). Jeśli klient nie ma takiego konceptu, wskaż dowolny prosty model "
        "z jednym polem 'nazwa' — patrz README.md, sekcja core_magazyn."
    )


class Kategoria(models.Model):
    nazwa = models.CharField('nazwa', max_length=100, unique=True)

    class Meta:
        verbose_name = 'kategoria'
        verbose_name_plural = 'kategorie'
        ordering = ['nazwa']

    def __str__(self):
        return self.nazwa


class PrzedmiotBazowy(models.Model):
    WLASCICIEL_AGENCJA = 'agencja'
    WLASCICIEL_OBIEKT = 'obiekt'
    WLASCICIEL_PRYWATNY = 'prywatny'
    WLASCICIEL_CHOICES = [
        (WLASCICIEL_AGENCJA, 'Agencja'),
        (WLASCICIEL_OBIEKT, 'Obiekt'),
        (WLASCICIEL_PRYWATNY, 'Osoba prywatna'),
    ]

    nazwa = models.CharField('nazwa', max_length=200)
    kategoria = models.ForeignKey(
        Kategoria, on_delete=models.SET_NULL, null=True, blank=True, related_name='%(class)s_set',
    )
    wlasciciel_typ = models.CharField(
        'właściciel', max_length=15, choices=WLASCICIEL_CHOICES, default=WLASCICIEL_AGENCJA,
    )
    wlasciciel_obiekt = models.ForeignKey(
        _WLASCICIEL_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='%(class)s_wlasciciel', verbose_name='obiekt-właściciel',
        help_text='Wypełnij tylko gdy właściciel = obiekt.',
    )
    wlasciciel_opis = models.CharField(
        'opis właściciela', max_length=200, blank=True,
        help_text='Wypełnij tylko gdy właściciel = osoba prywatna, np. imię i nazwisko.',
    )
    opiekun = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='%(class)s_opiekun', verbose_name='opiekun w zespole',
    )
    notatki = models.TextField('notatki', blank=True)

    class Meta:
        abstract = True

    def clean(self):
        if self.wlasciciel_typ == self.WLASCICIEL_OBIEKT and not self.wlasciciel_obiekt_id:
            raise ValidationError('Właściciel „obiekt” wymaga wskazania obiektu.')
        if self.wlasciciel_typ != self.WLASCICIEL_OBIEKT and self.wlasciciel_obiekt_id:
            raise ValidationError('Obiekt-właściciel ma sens tylko przy właścicielu „obiekt”.')
        if self.wlasciciel_typ == self.WLASCICIEL_PRYWATNY and not self.wlasciciel_opis:
            raise ValidationError('Właściciel „osoba prywatna” wymaga opisu (np. imienia i nazwiska).')
        if self.wlasciciel_typ != self.WLASCICIEL_PRYWATNY and self.wlasciciel_opis:
            raise ValidationError('Opis właściciela ma sens tylko przy właścicielu „osoba prywatna”.')


class PrzedmiotZbiorczy(PrzedmiotBazowy):
    JEDNOSTKA_SZTUKA = 'szt'
    JEDNOSTKA_KOMPLET = 'kpl'
    JEDNOSTKA_CHOICES = [(JEDNOSTKA_SZTUKA, 'szt'), (JEDNOSTKA_KOMPLET, 'kpl')]

    jednostka = models.CharField('jednostka', max_length=10, choices=JEDNOSTKA_CHOICES, default=JEDNOSTKA_SZTUKA)
    ilosc_na_stanie = models.DecimalField(
        'ilość na stanie', max_digits=8, decimal_places=0, default=0,
        validators=[MinValueValidator(0)],
    )
    minimalny_stan = models.DecimalField(
        'minimalny stan', max_digits=8, decimal_places=0, default=0,
        validators=[MinValueValidator(0)],
    )

    history = HistoricalRecords()

    class Meta:
        verbose_name = 'przedmiot (ilościowo)'
        verbose_name_plural = 'przedmioty zbiorcze (magazyn)'
        ordering = ['nazwa']

    def __str__(self):
        return f'{self.nazwa} ({self.ilosc_na_stanie} {self.jednostka})'

    @property
    def stan_niski(self):
        return self.ilosc_na_stanie <= self.minimalny_stan


class PrzedmiotSeryjny(PrzedmiotBazowy):
    STAN_SPRAWNY = 'sprawny'
    STAN_USZKODZONY = 'uszkodzony'
    STAN_W_NAPRAWIE = 'w_naprawie'
    STAN_CHOICES = [
        (STAN_SPRAWNY, 'Sprawny'),
        (STAN_USZKODZONY, 'Uszkodzony'),
        (STAN_W_NAPRAWIE, 'W naprawie'),
    ]

    numer_inwentarzowy = models.CharField('numer inwentarzowy', max_length=50, unique=True)
    stan = models.CharField('stan', max_length=20, choices=STAN_CHOICES, default=STAN_SPRAWNY)

    history = HistoricalRecords()

    class Meta:
        verbose_name = 'przedmiot (egzemplarz)'
        verbose_name_plural = 'przedmioty seryjne (magazyn)'
        ordering = ['nazwa']

    def __str__(self):
        return f'{self.nazwa} ({self.numer_inwentarzowy})'


class Przeglad(models.Model):
    TYP_PRZEGLAD = 'przeglad'
    TYP_NAPRAWA = 'naprawa'
    TYP_SERWIS = 'serwis'
    TYP_UBYTEK = 'ubytek'
    TYP_CHOICES = [
        (TYP_PRZEGLAD, 'Przegląd'),
        (TYP_NAPRAWA, 'Naprawa'),
        (TYP_SERWIS, 'Serwis'),
        (TYP_UBYTEK, 'Ubytek (stłuczenie, zgubienie itp.)'),
    ]

    przedmiot_zbiorczy = models.ForeignKey(
        PrzedmiotZbiorczy, on_delete=models.CASCADE, null=True, blank=True, related_name='przeglady',
    )
    przedmiot_seryjny = models.ForeignKey(
        PrzedmiotSeryjny, on_delete=models.CASCADE, null=True, blank=True, related_name='przeglady',
    )
    data = models.DateField('data', default=timezone.now)
    typ = models.CharField('rodzaj', max_length=20, choices=TYP_CHOICES, default=TYP_PRZEGLAD)
    opis = models.TextField('co było robione / co się stało', blank=True)
    wykonal = models.CharField('wykonał', max_length=200, blank=True)
    dodal = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='przeglady_magazynowe_dodane',
    )
    dodano = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'przegląd / zdarzenie'
        verbose_name_plural = 'przeglądy i zdarzenia'
        ordering = ['-data', '-dodano']
        constraints = [
            models.CheckConstraint(
                condition=(
                    Q(przedmiot_zbiorczy__isnull=False, przedmiot_seryjny__isnull=True) |
                    Q(przedmiot_zbiorczy__isnull=True, przedmiot_seryjny__isnull=False)
                ),
                name='przeglad_dokladnie_jeden_przedmiot',
                violation_error_message='Wskaż dokładnie jeden przedmiot (zbiorczy albo seryjny), nie oba i nie żaden.',
            ),
        ]

    def __str__(self):
        przedmiot = self.przedmiot_zbiorczy or self.przedmiot_seryjny
        return f'{self.get_typ_display()} — {przedmiot} ({self.data})'
