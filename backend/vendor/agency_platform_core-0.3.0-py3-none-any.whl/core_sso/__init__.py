"""core_sso — produkt rodziny sudomie jako klient OIDC Konta sudomie (https://konto.sudomie.pl).

Instalacja w produkcie (CLAUDE.md, „Rodzina produktów sudomie”):
    INSTALLED_APPS += ["core_sso"]
    urlpatterns += [path("oidc/", include("core_sso.urls"))]   # redirect_uri = https://<host>/oidc/callback/
    OIDC_ISSUER / OIDC_CLIENT_ID / OIDC_CLIENT_SECRET   — z `manage.py klient_oidc <produkt> …` w Koncie
    OIDC_NAZWA = "Konto sudomie"                         — napis na przycisku
    SSO_PRODUKT = "kalendarz"                            — klucz w claimie firmy[].produkty (Konto/produkty.json)
    SSO_FIRMA = "<uuid>"                                 — produkt jednofirmowy; puste = wielofirmowy (np. Grafik)
    SSO_PO_ZALOGOWANIU = "app.modul.funkcja"             — f(user, firmy) nadaje role w produkcie
Puste OIDC_ISSUER = logowanie przez Konto wyłączone (flaga) — widoki odsyłają na LOGIN_URL.
Kontrakt claimów: Konto/docs/PROJEKT.md.
"""
