from django.contrib import admin

from .models import TozsamoscZewnetrzna


@admin.register(TozsamoscZewnetrzna)
class TozsamoscAdmin(admin.ModelAdmin):
    list_display = ["user", "issuer", "sub", "ostatnio"]
    search_fields = ["sub"]
    readonly_fields = ["utworzono", "ostatnio"]
