from django.apps import AppConfig


class CoreSsoConfig(AppConfig):
    name = "core_sso"
    verbose_name = "Logowanie kontem sudomie"
    default_auto_field = "django.db.models.BigAutoField"
