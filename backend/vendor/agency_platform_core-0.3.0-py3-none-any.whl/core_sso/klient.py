"""Klient OIDC (authlib + discovery). authlib to zależność opcjonalna: pip install agency-platform-core[sso]."""
from django.conf import settings

_oauth = None


def klient():
    """Zarejestrowany klient albo None, gdy logowanie przez Konto jest wyłączone (puste OIDC_ISSUER)."""
    global _oauth
    issuer = getattr(settings, "OIDC_ISSUER", "").rstrip("/")
    if not issuer:
        return None
    if _oauth is None:
        from authlib.integrations.django_client import OAuth

        _oauth = OAuth()
        _oauth.register(
            "konto", server_metadata_url=getattr(settings, "OIDC_DISCOVERY_URL", "") or f"{issuer}/.well-known/openid-configuration/",
            client_id=settings.OIDC_CLIENT_ID, client_secret=settings.OIDC_CLIENT_SECRET,
            client_kwargs={"scope": "openid profile email firmy", "code_challenge_method": "S256", "timeout": 10},
        )
    return _oauth.konto
