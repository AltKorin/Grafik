from django.conf import settings
from django.db import models


class TozsamoscZewnetrzna(models.Model):
    """Konto w Koncie sudomie przypięte do konta w produkcie.
    Klucz = (issuer, sub): login/e-mail w Koncie może się zmienić, sub nie. Nigdy nie wiążemy po loginie."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="tozsamosci_sso")
    issuer = models.CharField(max_length=200)
    sub = models.CharField(max_length=200)
    utworzono = models.DateTimeField(auto_now_add=True)
    ostatnio = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "konto sudomie"
        verbose_name_plural = "konta sudomie"
        constraints = [models.UniqueConstraint(fields=["issuer", "sub"], name="core_sso_tozsamosc_unikalna")]

    def __str__(self):
        return f"{self.user} ← {self.issuer} #{self.sub}"
