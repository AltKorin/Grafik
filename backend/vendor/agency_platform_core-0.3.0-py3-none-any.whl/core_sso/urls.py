from django.urls import path

from . import views

app_name = "core_sso"
urlpatterns = [
    path("login/", views.zaloguj, name="login"),
    path("callback/", views.callback, name="callback"),
]
