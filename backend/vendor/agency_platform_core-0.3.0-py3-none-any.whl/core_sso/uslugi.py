"""Logowanie kontem sudomie — logika niezależna od produktu.

Prawa (tests/test_core_sso.py):
- konto wiążemy WYŁĄCZNIE po (issuer, sub) — nigdy po loginie/e-mailu (brak przejęcia cudzego konta lokalnego),
- bez dostępu do TEGO produktu (klucz SSO_PRODUKT w firmy[].produkty) nikt nie wchodzi i konto nie powstaje,
- produkt jednofirmowy (SSO_FIRMA) wpuszcza tylko członków tej firmy,
- konto wyłączone w produkcie (is_active=False) nie wejdzie także przez Konto,
- imię i role synchronizują się przy każdym logowaniu (odebranie dostępu w Koncie działa od razu),
- śmieciowe claimy (brak sub, firmy nie-listą, produkty nie-słownikiem) = odmowa, nie wyjątek.
"""
import re
import unicodedata

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils.module_loading import import_string

KOMUNIKATY = {
    "konfiguracja": "Logowanie kontem sudomie nie jest skonfigurowane.",
    "brak_firmy": "Twoje konto nie należy do tej firmy. Poproś właściciela o zaproszenie w Koncie sudomie.",
    "brak_dostepu": "Nie masz dostępu do tej aplikacji. Poproś właściciela firmy o dostęp w Koncie sudomie.",
    "wylaczone": "Twoje konto w tej aplikacji jest wyłączone. Skontaktuj się z właścicielem firmy.",
}


def komunikat(klucz):
    return {**KOMUNIKATY, **getattr(settings, "SSO_KOMUNIKATY", {})}[klucz]


def firmy_produktu(claims, kod, firma=None):
    """[{"id", "nazwa", "rola", "wlasciciel"}] — firmy z dostępem do produktu `kod` (tylko `firma`, jeśli podana)."""
    wynik = []
    lista = claims.get("firmy") if isinstance(claims, dict) else None
    for f in lista if isinstance(lista, list) else []:
        if not isinstance(f, dict) or (firma and str(f.get("id")) != str(firma)):
            continue
        produkty = f.get("produkty")
        rola = produkty.get(kod) if isinstance(produkty, dict) else None
        if isinstance(rola, str) and rola:
            wynik.append({"id": str(f.get("id")), "nazwa": str(f.get("nazwa") or ""), "rola": rola,
                          "wlasciciel": bool(f.get("wlasciciel"))})
    return wynik


def _slug(tekst):
    t = unicodedata.normalize("NFKD", str(tekst).replace("ł", "l").replace("Ł", "L")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9.]+", ".", t.lower()).strip(".")[:120] or "konto"


def _nowe_konto(claims, sub):
    User = get_user_model()
    pole = User.USERNAME_FIELD
    baza = _slug(str(claims.get("preferred_username") or claims.get("email") or f"konto{sub}").split("@")[0])
    login, i = baza, 1
    while User.objects.filter(**{pole: login}).exists():  # istniejące konto lokalne zostaje nietknięte
        i += 1
        login = f"{baza}{i}"
    user = User(**{pole: login})
    if hasattr(user, "email"):
        user.email = str(claims.get("email") or "")[:254]
    user.set_unusable_password()  # wchodzi tylko przez Konto
    user.save()
    return user


def konto_z_oidc(claims, issuer=None, kod=None, firma=None):
    """Claimy z Konta → (user, firmy, None) albo (None, [], komunikat). Domyślne wartości z settings (OIDC_ISSUER,
    SSO_PRODUKT, SSO_FIRMA). Po związaniu konta woła SSO_PO_ZALOGOWANIU(user, firmy) — produkt nadaje role."""
    from .models import TozsamoscZewnetrzna

    issuer = (issuer or getattr(settings, "OIDC_ISSUER", "")).rstrip("/")
    kod = kod or getattr(settings, "SSO_PRODUKT", "")
    firma = firma if firma is not None else getattr(settings, "SSO_FIRMA", "")
    sub = str(claims.get("sub") or "").strip() if isinstance(claims, dict) else ""
    if not sub or not issuer or not kod:
        return None, [], komunikat("konfiguracja")
    firmy = firmy_produktu(claims, kod, firma or None)
    if not firmy:
        lista = claims.get("firmy") if isinstance(claims.get("firmy"), list) else []
        w_firmie = any(isinstance(f, dict) and str(f.get("id")) == str(firma) for f in lista)
        return None, [], komunikat("brak_firmy" if firma and not w_firmie else "brak_dostepu")
    with transaction.atomic():
        t = TozsamoscZewnetrzna.objects.select_related("user").filter(issuer=issuer, sub=sub).first()
        if t:
            user = t.user
            if not getattr(user, "is_active", True):
                return None, [], komunikat("wylaczone")
            t.save(update_fields=["ostatnio"])
        else:
            user = _nowe_konto(claims, sub)
            TozsamoscZewnetrzna.objects.create(user=user, issuer=issuer, sub=sub)
        if hasattr(user, "first_name"):
            user.first_name = str(claims.get("name") or claims.get("preferred_username") or "")[:150]
            user.save(update_fields=["first_name"])
        hook = getattr(settings, "SSO_PO_ZALOGOWANIU", "")
        if hook:
            import_string(hook)(user, firmy)
    return user, firmy, None


def powiaz(user, issuer, sub):
    """Ręczne powiązanie istniejącego konta produktu z kontem w Koncie (migracja kont, np. z Grafiku). Idempotentne;
    sub zajęty przez INNE konto = błąd (nie przepinamy po cichu)."""
    from .models import TozsamoscZewnetrzna

    issuer, sub = issuer.rstrip("/"), str(sub)
    t = TozsamoscZewnetrzna.objects.filter(issuer=issuer, sub=sub).first()
    if t and t.user_id != user.pk:
        raise ValueError(f"Konto sudomie #{sub} jest już powiązane z innym kontem ({t.user}).")
    return t or TozsamoscZewnetrzna.objects.create(user=user, issuer=issuer, sub=sub)
