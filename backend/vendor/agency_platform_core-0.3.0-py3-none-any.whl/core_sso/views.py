import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.signals import user_login_failed
from django.shortcuts import redirect, resolve_url
from django.urls import reverse

from . import uslugi
from .klient import klient

log = logging.getLogger(__name__)


def _strona_logowania():
    return resolve_url(getattr(settings, "SSO_URL_LOGOWANIA", settings.LOGIN_URL))


def _bezpieczny(next_url):
    n = str(next_url or "")
    return n if n.startswith("/") and not n.startswith("//") and "\\" not in n else "/"


def zaloguj(request):
    k = klient()
    if not k:
        return redirect(_strona_logowania())
    request.session["sso_next"] = _bezpieczny(request.GET.get("next"))
    return k.authorize_redirect(request, request.build_absolute_uri(reverse("core_sso:callback")))


def callback(request):
    k = klient()
    if not k:
        return redirect(_strona_logowania())
    nazwa = getattr(settings, "OIDC_NAZWA", "Konto sudomie")
    try:
        token = k.authorize_access_token(request)
        claims = token.get("userinfo") or k.parse_id_token(token, nonce=None)
    except Exception:  # odrzucone logowanie, zły state, dostawca niedostępny
        log.exception("SSO: callback nieudany")
        messages.error(request, f"Nie udało się zalogować przez {nazwa}. Spróbuj jeszcze raz.")
        return redirect(_strona_logowania())
    user, _, blad = uslugi.konto_z_oidc(claims)
    if blad:
        user_login_failed.send(sender=__name__, request=request,
                               credentials={"username": f"{claims.get('preferred_username', '')}@{nazwa}"})
        messages.error(request, blad)
        return redirect(_strona_logowania())
    login(request, user, backend="django.contrib.auth.backends.ModelBackend")
    return redirect(_bezpieczny(request.session.pop("sso_next", "/")))
